// Imports the Google Cloud client library
const vision = require('@google-cloud/vision');
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Set the environment variable for authentication
process.env.GOOGLE_APPLICATION_CREDENTIALS = 'D:\\Bangkit\\Capstone\\percobaan\\mlcc\\byetrashfe7bd0081778.json';
// Creates a client
const client = new vision.ImageAnnotatorClient();

// Initialize Express app
const app = express();
const upload = multer({ dest: 'uploads/' });

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Serve the homepage at the root URL
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/homepage', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'homepage.html'));
});

app.post('/upload', upload.single('image'), async (req, res) => {
    let filePath;
    if (req.file) {
        filePath = path.join(__dirname, req.file.path);
        console.log(`File uploaded: ${filePath}`);
    } else if (req.body.image) {
        const base64Data = req.body.image.replace(/^data:image\/png;base64,/, "");
        filePath = path.join(__dirname, 'uploads', 'camera_image.png');
        fs.writeFileSync(filePath, base64Data, 'base64');
        console.log(`Image captured from camera: ${filePath}`);
    }

    try {
        // Performs label detection on the uploaded file
        const [result] = await client.labelDetection(filePath);
        const labels = result.labelAnnotations;
        console.log('Labels detected:', labels);

        // Expanded list of recyclable materials
        const recyclableLabels = [
            'Plastic', 'Paper', 'Glass', 'Metal', 'Cardboard', 'Aluminum', 'Steel', 'Tin', 'Copper', 'Electronics', 'Batteries'
        ];
        const isRecyclable = labels.some(label => recyclableLabels.includes(label.description));

        let message;
        if (isRecyclable) {
            message = 'The waste is recyclable. Put it into recycling.';
        } else {
            message = 'The waste cannot be recycled.';
        }

        // Send response with labels and prediction result
        res.json({
            message: message,
            labels: labels.map(label => ({
                description: label.description,
                score: (label.score * 100).toFixed(2)
            }))
        });
    } catch (error) {
        console.error('Error processing image:', error);
        res.status(500).json({ error: 'Error processing image.' });
    } finally {
        // Clean up the uploaded file
        if (req.file) {
            fs.unlinkSync(filePath);
        }
    }
});

app.listen(3000, () => {
    console.log('Server started on http://localhost:3000');
});